### google_chart_guide

#### How to start
1. `git clone` the repo
2. `npm install`
3. run with the command `DEBUG=google_chart_guide:* ./bin/www`